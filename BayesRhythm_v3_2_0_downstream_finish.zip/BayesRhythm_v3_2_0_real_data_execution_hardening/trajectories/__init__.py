"""BayesRhythm trajectories package."""
