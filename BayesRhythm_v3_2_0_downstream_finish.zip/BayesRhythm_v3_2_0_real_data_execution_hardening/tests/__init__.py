"""BayesRhythm tests package."""
