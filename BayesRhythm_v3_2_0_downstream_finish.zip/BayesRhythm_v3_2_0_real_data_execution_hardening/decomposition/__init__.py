"""BayesRhythm decomposition package."""
