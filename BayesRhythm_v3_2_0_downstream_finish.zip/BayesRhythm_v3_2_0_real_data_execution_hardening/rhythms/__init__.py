"""BayesRhythm rhythms package."""
